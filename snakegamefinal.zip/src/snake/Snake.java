package snake;

import java.awt.*;
import java.util.ArrayList;
import snake.types.Direction;

/**
 * Represents a snake in the game.
 */
public class Snake {

    static {
        System.loadLibrary("snakenative"); // Load the native library
    }

    private Direction heading; // The direction the snake is heading
    private Direction nextHeading; // The direction the snake will head next
    private ArrayList<Integer[]> coordinates = new ArrayList<>(1); // The snake's body coordinates
    private ArrayList<Integer[]> previousCoordinates = coordinates; // Coordinates from the previous frame
    private int needsIncreasing = 2; // The number of tiles to grow
    private boolean isAlive = true; // Whether the snake is alive
    private final int TYPE; // The snake's type
    private int aliveSince = 0; // When the snake was born (seconds)
    private int aliveFor = -1; // How long the snake was alive

    public Snake(int startX, int startY, Direction heading, int TYPE) {
        coordinates.add(new Integer[]{startX, startY});

        this.heading = heading;
        this.nextHeading = heading;
        this.TYPE = TYPE;

        // Initial length of 2 tiles for aesthetics
        switch (heading) {
            case NORTH -> coordinates.add(new Integer[]{startX, startY + 1});
            case EAST -> coordinates.add(new Integer[]{startX - 1, startY});
            case SOUTH -> coordinates.add(new Integer[]{startX, startY - 1});
            case WEST -> coordinates.add(new Integer[]{startX + 1, startY});
        }
    }

    public void move() {
        if (!isAlive) return;

        heading = moveNative(coordinates, heading.ordinal(), nextHeading.ordinal(), needsIncreasing);
    }

    public void setHeading(Direction heading) {
        nextHeading = setHeadingNative(this.heading.ordinal(), heading.ordinal());
    }

    public Color getColor() {
        int[] rgb = getColorNative(TYPE, isAlive);
        return new Color(rgb[0], rgb[1], rgb[2]);
    }

    private native Direction moveNative(ArrayList<Integer[]> coordinates, int heading, int nextHeading, int needsIncreasing);

    private native Direction setHeadingNative(int currentHeading, int newHeading);

    private native int[] getColorNative(int type, boolean isAlive);
}
