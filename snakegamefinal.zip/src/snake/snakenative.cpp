#include "snakeNative.h"
#include <vector>
#include <utility>

// Helper enum for directions
enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST
};



// Implement moveNative
JNIEXPORT jint JNICALL Java_snake_Snake_moveNative
(JNIEnv *env, jobject obj, jobject coordinates, jint heading, jint nextHeading, jint needsIncreasing) {
    jclass arrayListClass = env->GetObjectClass(coordinates);
    jmethodID sizeMethod = env->GetMethodID(arrayListClass, "size", "()I");
    jint size = env->CallIntMethod(coordinates, sizeMethod);

    std::vector<std::pair<int, int>> snakeBody;
    jmethodID getMethod = env->GetMethodID(arrayListClass, "get", "(I)Ljava/lang/Object;");

    for (int i = 0; i < size; ++i) {
        jobject point = env->CallObjectMethod(coordinates, getMethod, i);
        jclass pointClass = env->GetObjectClass(point);
        jint x = env->CallIntMethod(point, env->GetMethodID(pointClass, "get", "(I)I"), 0);
        jint y = env->CallIntMethod(point, env->GetMethodID(pointClass, "get", "(I)I"), 1);
        snakeBody.emplace_back(x, y);
    }

    Direction dir = static_cast<Direction>(heading);
    Direction nextDir = static_cast<Direction>(nextHeading);

    switch (dir) {
        case NORTH: if (nextDir != SOUTH) dir = nextDir; break;
        case EAST: if (nextDir != WEST) dir = nextDir; break;
        case SOUTH: if (nextDir != NORTH) dir = nextDir; break;
        case WEST: if (nextDir != EAST) dir = nextDir; break;
    }

    auto head = snakeBody.front();
    switch (dir) {
        case NORTH: head.second -= 1; break;
        case EAST: head.first += 1; break;
        case SOUTH: head.second += 1; break;
        case WEST: head.first -= 1; break;
    }
    snakeBody.insert(snakeBody.begin(), head);

    if (needsIncreasing <= 0) {
        snakeBody.pop_back();
    }

    return static_cast<jint>(dir);
}

// Implement setHeadingNative
JNIEXPORT jint JNICALL Java_snake_Snake_setHeadingNative
(JNIEnv *env, jobject obj, jint currentHeading, jint newHeading) {
    Direction current = static_cast<Direction>(currentHeading);
    Direction next = static_cast<Direction>(newHeading);

    switch (current) {
        case NORTH: if (next != SOUTH) return next; break;
        case EAST: if (next != WEST) return next; break;
        case SOUTH: if (next != NORTH) return next; break;
        case WEST: if (next != EAST) return next; break;
    }
    return current;
}

// Implement getColorNative
JNIEXPORT jintArray JNICALL Java_snake_Snake_getColorNative
(JNIEnv *env, jobject obj, jint type, jboolean isAlive) {
    jintArray rgb = env->NewIntArray(3);
    jint color[3];
    if (isAlive) {
        color[0] = 0; // Replace with actual logic to get R
        color[1] = 255; // Replace with actual logic to get G
        color[2] = 0; // Replace with actual logic to get B
    } else {
        color[0] = 128; // Gray
        color[1] = 128;
        color[2] = 128;
    }
    env->SetIntArrayRegion(rgb, 0, 3, color);
    return rgb;
}
