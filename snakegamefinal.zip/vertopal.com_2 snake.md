# 2 Snake Game

A **two-player Snake game** built in Java, leveraging Swing for its
graphical user interface. The game provides a nostalgic gameplay
experience with added multiplayer support, customizable settings, and a
polished graphical interface.

------------------------------------------------------------------------

## Table of Contents

-   [Project Overview](#project-overview)
-   [Features](#features)
-   [Project Structure](#project-structure)
-   [Prerequisites](#prerequisites)
-   [Build Instructions](#build-instructions)
-   [Run Instructions](#run-instructions)
-   [Customization](#customization)
-   [Troubleshooting](#troubleshooting)
-   [Contributing](#contributing)
-   [License](#license)

------------------------------------------------------------------------

## Project Overview

The **Snake Game** is designed to offer a competitive two-player mode
where players can control separate snakes on the same screen. The game
board adapts to different configurations, and players can tweak gameplay
settings via a configuration file. The codebase is modular, separating
game logic, configuration handling, and graphical rendering for
maintainability.

------------------------------------------------------------------------

## Features

-   **Two-Player Gameplay**: Share the screen with a friend and compete
    to dominate the board.
-   **Customizable Settings**: Modify grid size, snake speeds, and other
    settings via a configuration file.
-   **Classic Snake Experience**: Relive the nostalgia of the classic
    snake game with smooth animations and intuitive controls.
-   **Pause and Restart**: Pause the game mid-session or restart easily
    without re-launching.
-   **Cross-Platform**: Runs on any system with Java support.

------------------------------------------------------------------------

## Project Structure

    SnakeGame/
    ├── src/
    │   ├── Main.java          # Main entry point for the application
    │   ├── engine/            # Game engine logic
    │   ├── snake/             # Snake game mechanics and rendering
    │   ├── assets/            # Media files (images, sounds)
    ├── nbproject/             # NetBeans project files
    ├── build.xml              # Apache Ant build file
    ├── configuration.txt      # Configuration settings for the game
    ├── SnakeGame.iml          # IntelliJ IDEA module file

-   **`src/`**: Contains the main application logic organized into
    sub-packages.
-   **`assets/`**: Houses images or other resources used by the game.
-   **`configuration.txt`**: Allows users to tweak gameplay parameters.

------------------------------------------------------------------------

## Prerequisites

To build and run the project, ensure the following are installed:

-   **Java Development Kit (JDK)**: Version 8 or higher.
-   **Apache Ant**: For automating the build process.
-   **A Code Editor**: Optional, for modifying the source code (e.g.,
    IntelliJ IDEA, NetBeans).

------------------------------------------------------------------------

## Build Instructions

1.  **Clone or Extract the Project**: Ensure the project directory
    contains all required files, including `build.xml`.

2.  **Compile the Project**: Open a terminal, navigate to the project
    directory, and run:

    ``` bash
    ant compile
    ```

    This command compiles the Java files and places the output in the
    `build/classes` directory.

3.  **Package into JAR (Optional)**: Create an executable JAR file by
    running:

    ``` bash
    ant jar
    ```

    The resulting JAR file will be located in the `dist` directory.

------------------------------------------------------------------------

## Run Instructions

### From the Command Line

1.  **Direct Execution**: After compilation, run the application using:

    ``` bash
    java -cp build/classes Main
    ```

2.  **Using the JAR**: If the project was packaged into a JAR, execute
    it with:

    ``` bash
    java -jar dist/SnakeGame.jar
    ```

------------------------------------------------------------------------

## Customization

### Editing the Configuration File

The game behavior can be modified by adjusting `configuration.txt`. Key
parameters include:

-   **Grid Size**: Adjust the width and height of the game grid.

        grid_width=30
        grid_height=20

-   **Snake Speed**: Modify the refresh rate for the game loop to
    control snake movement speed.

        snake_speed=100

-   **Other Options**: Check the file for additional settings, such as
    colors, player controls, and modes.

### Adding Assets

Place new images or sounds in the `assets` folder. Update the source
code if necessary to reference these assets.

------------------------------------------------------------------------

## Troubleshooting

1.  **Game Won't Start**: Ensure all required files
    (`configuration.txt`, assets) are present in the working directory.

2.  **Error Messages**: Common Java errors like `ClassNotFoundException`
    or `NoClassDefFoundError` occur when the classpath is not correctly
    set. Verify the `build/classes` directory is included in the
    classpath.

3.  **Build Fails**:

    -   Ensure Apache Ant is installed and added to your system's PATH.
    -   Double-check the Java version using `java -version`.

4.  **Customization Issues**: If configuration changes aren't applied,
    confirm the `configuration.txt` file is correctly formatted.

------------------------------------------------------------------------

## Contributing

Contributions are welcome! To contribute:

1.  Fork the repository.
2.  Create a new branch for your feature.
3.  Submit a pull request detailing your changes.

------------------------------------------------------------------------

## License

This project is licensed under the MIT License. See `LICENSE` for
details.

------------------------------------------------------------------------

Enjoy playing the **Snake Game** and feel free to tweak it to make it
even better!

------------------------------------------------------------------------
